from .T_S_I_V_ import table_T_S_I_V_

class table_T_S_I_J_(table_T_S_I_V_):
	pass
